package com.ecoparty.app;

import android.app.*;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import android.content.*;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import java.util.*;

public class MainActivity extends Activity {
    final int BG=Color.rgb(10,7,22), CARD=Color.rgb(28,22,45), CARD2=Color.rgb(39,30,61);
    final int PURPLE=Color.rgb(133,72,255), PINK=Color.rgb(236,74,164), WHITE=Color.WHITE, MUTED=Color.rgb(184,176,202);
    LinearLayout root, content; TextView title;
    FirebaseAuth auth; FirebaseFirestore db; FirebaseUser currentUser;
    // ECO PARTY owner account: linked to the Firebase Authentication UID supplied by the owner.
    static final String OWNER_AUTH_UID = "YALOZ3c4jiTjLpl7BXScn7a3Auq2";
    String displayName="User", publicId="", avatar="🙂"; int level=1, vip=0; boolean owner=false, unlimited=false;
    long diamonds=100;

    @Override public void onCreate(Bundle b){ super.onCreate(b); auth=FirebaseAuth.getInstance(); db=FirebaseFirestore.getInstance();
        if(auth.getCurrentUser()!=null){ currentUser=auth.getCurrentUser(); loadProfile(); } else showLogin(); }

    TextView tv(String s,float size){ TextView v=new TextView(this); v.setText(s); v.setTextSize(size); v.setTextColor(WHITE); v.setPadding(16,8,16,8); return v; }
    TextView center(String s,float size){ TextView v=tv(s,size); v.setGravity(Gravity.CENTER); return v; }
    GradientDrawable gd(int c,float r){ GradientDrawable g=new GradientDrawable(); g.setColor(c); g.setCornerRadius(r); return g; }
    Button btn(String s){ Button b=new Button(this); b.setText(s); b.setTextColor(WHITE); b.setTextSize(14); b.setAllCaps(false); b.setBackground(gd(PURPLE,55)); return b; }
    LinearLayout box(){ LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(14,12,14,12); l.setBackground(gd(CARD,28)); return l; }

    void showLogin(){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setGravity(Gravity.CENTER); root.setPadding(28,20,28,30); root.setBackgroundColor(BG); setContentView(root);
        TextView logo=center("👑\nECO PARTY",30); logo.setTypeface(Typeface.DEFAULT,Typeface.BOLD); root.addView(logo,new LinearLayout.LayoutParams(-1,0,1));
        TextView sub=center("Voice • Party • Gifts • VIP",14); sub.setTextColor(MUTED); root.addView(sub);
        LinearLayout card=box(); EditText email=new EditText(this); email.setHint("Email"); email.setTextColor(WHITE); email.setHintTextColor(MUTED); card.addView(email,new LinearLayout.LayoutParams(-1,55));
        EditText pass=new EditText(this); pass.setHint("Password (6+ characters)"); pass.setInputType(0x81); pass.setTextColor(WHITE); pass.setHintTextColor(MUTED); card.addView(pass,new LinearLayout.LayoutParams(-1,55));
        Button login=btn("Login"); card.addView(login,new LinearLayout.LayoutParams(-1,54));
        Button signup=btn("Create New Account"); signup.setBackground(gd(CARD2,55)); card.addView(signup,new LinearLayout.LayoutParams(-1,54)); root.addView(card,new LinearLayout.LayoutParams(-1,-2));
        TextView note=center("Your account data is saved in ECO PARTY Firebase.",12); note.setTextColor(MUTED); root.addView(note,new LinearLayout.LayoutParams(-1,55));
        login.setOnClickListener(v->emailLogin(email.getText().toString().trim(),pass.getText().toString()));
        signup.setOnClickListener(v->emailSignup(email.getText().toString().trim(),pass.getText().toString()));
    }

    void emailLogin(String email,String password){ if(email.isEmpty()||password.isEmpty()){toast("Email aur password bharo");return;} loading(true); auth.signInWithEmailAndPassword(email,password).addOnCompleteListener(t->{loading(false); if(t.isSuccessful()){currentUser=auth.getCurrentUser(); loadProfile();}else toast("Login failed: "+(t.getException()==null?"Try again":t.getException().getMessage()));}); }
    void emailSignup(String email,String password){ if(email.isEmpty()||password.length()<6){toast("Valid email aur 6+ character password bharo");return;} loading(true); auth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(t->{ if(!t.isSuccessful()){loading(false);toast("Account create failed: "+(t.getException()==null?"Try again":t.getException().getMessage()));return;} currentUser=auth.getCurrentUser(); createNormalProfile(""); }); }
    void createNormalProfile(String ignored){
        // Temporary client-side public ID. Final production allocation should move server-side.
        long id=100000000L + (System.currentTimeMillis()%900000000L);
        saveNewUser(id);
    }
    void saveNewUser(long id){ publicId=String.valueOf(id); Map<String,Object> m=new HashMap<>(); m.put("uid",currentUser.getUid()); m.put("email",currentUser.getEmail()); m.put("name", "User"); m.put("userId",id); m.put("level",1); m.put("vipLevel",0); m.put("diamonds",100L); m.put("xp",0L); m.put("isOwner",false); m.put("unlimitedDiamonds",false); m.put("titles",new ArrayList<String>()); db.collection("users").document(currentUser.getUid()).set(m).addOnCompleteListener(x->{loading(false); if(x.isSuccessful()){displayName="User";level=1;vip=0;diamonds=100;owner=false;unlimited=false;showHome();}else toast("Profile save failed");}); }

    void loadProfile(){
        // First verify the authenticated Firebase account. This prevents a normal account
        // from becoming owner merely by changing a profile name or public ID.
        if(currentUser != null && OWNER_AUTH_UID.equals(currentUser.getUid())){
            // The owner profile remains in Firestore as users/thor_owner.
            // We also have a safe prototype fallback so the owner screen still opens if
            // the Firestore rules temporarily block that document.
            db.collection("users").document("thor_owner").get().addOnSuccessListener(ownerDoc->{
                if(ownerDoc.exists()){ applyProfile(ownerDoc); }
                else { applyOwnerDefaults(); }
            }).addOnFailureListener(e->applyOwnerDefaults());
            return;
        }

        // All other authenticated accounts use their Firebase Auth UID as their profile document ID.
        db.collection("users").document(currentUser.getUid()).get().addOnSuccessListener(userDoc->{
            if(!userDoc.exists()){ createNormalProfile(""); return; }
            applyProfile(userDoc);
        }).addOnFailureListener(e->toast("Firebase profile load failed"));
    }

    void applyOwnerDefaults(){
        displayName="Thor"; publicId="100001"; level=100; vip=6; diamonds=Long.MAX_VALUE; owner=true; unlimited=true;
        showHome();
    }

    void applyProfile(DocumentSnapshot d){
        displayName=String.valueOf(d.getString("name")==null?"User":d.getString("name")); Long id=d.getLong("userId"); publicId=id==null?"":String.valueOf(id); Long lv=d.getLong("level"); level=lv==null?1:lv.intValue(); Long vp=d.getLong("vipLevel"); vip=vp==null?0:vp.intValue(); Long dia=d.getLong("diamonds"); diamonds=dia==null?100:dia; Boolean ow=d.getBoolean("isOwner"); owner=ow!=null&&ow; Boolean un=d.getBoolean("unlimitedDiamonds"); unlimited=un!=null&&un;
        // Owner status must come from the Firebase profile, never from the email typed into the app.
        showHome();
    }

    void loading(boolean x){ if(x) Toast.makeText(this,"Please wait…",Toast.LENGTH_SHORT).show(); }
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}

    void base(String t){ root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(BG); setContentView(root); LinearLayout head=new LinearLayout(this); head.setPadding(8,14,8,6); title=tv(t,23); title.setTypeface(Typeface.DEFAULT,Typeface.BOLD); head.addView(title,new LinearLayout.LayoutParams(0,58,1)); Button menu=btn("⋮"); menu.setTextSize(25); menu.setBackgroundColor(Color.TRANSPARENT); head.addView(menu,new LinearLayout.LayoutParams(58,58)); root.addView(head); content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(10,4,10,14); ScrollView sc=new ScrollView(this); sc.addView(content); root.addView(sc,new LinearLayout.LayoutParams(-1,0,1)); bottom(); }
    void bottom(){ LinearLayout nav=new LinearLayout(this); nav.setPadding(4,5,4,8); nav.setBackgroundColor(Color.rgb(17,13,31)); String[] names={"⌂\nHome","◉\nRooms","♛\nRank","●\nMine"}; for(int i=0;i<4;i++){Button b=new Button(this);b.setText(names[i]);b.setTextSize(11);b.setTextColor(MUTED);b.setAllCaps(false);b.setBackgroundColor(Color.TRANSPARENT);final int x=i;b.setOnClickListener(v->{if(x==0)showHome();if(x==1)showRooms();if(x==2)showRank();if(x==3)showProfile();});nav.addView(b,new LinearLayout.LayoutParams(0,66,1));}root.addView(nav); }
    void addChipRow(String... chips){ LinearLayout r=new LinearLayout(this);r.setPadding(4,2,4,8);for(String c:chips){TextView x=center(c,13);x.setBackground(gd(CARD2,40));r.addView(x,new LinearLayout.LayoutParams(0,42,1));}content.addView(r); }

    void showHome(){ base("ECO PARTY"); TextView sub=tv(owner?"👑 THOR • OWNER • VIP 6":"🎙 Talk  •  🎮 Play  •  🎁 Gift  •  👑 VIP",13); sub.setTextColor(owner?WHITE:MUTED); content.addView(sub); LinearLayout wallet=box(); TextView w=tv("💎 "+(unlimited?"∞":diamonds)+"     🪙 500     👑 VIP "+vip,17);w.setTypeface(Typeface.DEFAULT,Typeface.BOLD);wallet.addView(w);Button recharge=btn("＋ Recharge Diamonds");recharge.setOnClickListener(v->recharge());wallet.addView(recharge,new LinearLayout.LayoutParams(-1,52));content.addView(wallet); LinearLayout hero=box();TextView h=tv("🔥 Live Party Rooms",21);h.setTypeface(Typeface.DEFAULT,Typeface.BOLD);hero.addView(h);TextView hs=tv("Join a room, talk on mic and send gifts",13);hs.setTextColor(MUTED);hero.addView(hs);Button create=btn("＋ Create Room");create.setOnClickListener(v->createRoom());hero.addView(create,new LinearLayout.LayoutParams(-1,52));content.addView(hero);content.addView(tv("Popular right now",18));addChipRow("🇮🇳 India","🔥 Hot","🎵 Music","❤️ Friends");addRoom("Punjabi Night 🔥",26,"Host: Aman");addRoom("Desi Friends ❤️",18,"Host: Simran");addRoom("Late Night Talk 🌙",41,"Host: Karan"); }
    void addRoom(String name,int users,String host){LinearLayout b=box();LinearLayout row=new LinearLayout(this);TextView av=center("👤",34);row.addView(av,new LinearLayout.LayoutParams(58,62));LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);TextView n=tv(name,16);n.setTypeface(Typeface.DEFAULT,Typeface.BOLD);info.addView(n);TextView u=tv("🎙 "+host+"   •   👥 "+users+" online",12);u.setTextColor(MUTED);info.addView(u);row.addView(info,new LinearLayout.LayoutParams(0,66,1));Button j=btn("Join");j.setOnClickListener(v->room(name));row.addView(j,new LinearLayout.LayoutParams(80,50));b.addView(row);content.addView(b,new LinearLayout.LayoutParams(-1,90)); }
    void showRooms(){base("Live Rooms");TextView s=tv("Find your next room",14);s.setTextColor(MUTED);content.addView(s);addChipRow("All","Popular","New","Nearby");addRoom("Punjabi Night 🔥",24,"Lucky Singh");addRoom("Chill & Talk 💜",17,"Simran");addRoom("Music & Masti 🎵",33,"Karan");addRoom("Friends Forever ❤️",12,"Preet");Button c=btn("＋ Create New Room");c.setOnClickListener(v->createRoom());content.addView(c,new LinearLayout.LayoutParams(-1,56)); }
    void room(String name){base(name);TextView info=tv("🔴 LIVE   •   10 MIC SEATS   •   👥 26",13);info.setTextColor(MUTED);content.addView(info);LinearLayout banner=box();TextView bt=tv("Welcome everyone! Let's chat and have fun together!",14);banner.addView(bt);Button settings=btn("⚙ Room Settings");settings.setOnClickListener(v->roomSettings());banner.addView(settings,new LinearLayout.LayoutParams(-1,48));content.addView(banner);GridLayout grid=new GridLayout(this);grid.setColumnCount(5);for(int i=1;i<=10;i++){LinearLayout seat=box();seat.setGravity(Gravity.CENTER);TextView a=center(i==8?"👑":"🎙",28);seat.addView(a);TextView n=center(i==8?"THOR":"Seat "+i,11);n.setTextColor(i==8?WHITE:MUTED);seat.addView(n);grid.addView(seat,new ViewGroup.LayoutParams(0,98));}content.addView(grid);LinearLayout actions=new LinearLayout(this);String[] ac={"🎙 Mic","🎁 Gift","⚔ PK","🎮 Play","👥 Fans"};for(String x:ac){Button b=btn(x);b.setTextSize(12);if(x.contains("Gift"))b.setOnClickListener(v->gifts());if(x.contains("Play"))b.setOnClickListener(v->roomActivities());if(x.contains("PK"))b.setOnClickListener(v->pk());actions.addView(b,new LinearLayout.LayoutParams(0,54,1));}content.addView(actions);content.addView(tv("Room Chat",17));TextView chat=tv("💬 Welcome to ECO PARTY!\n💬 Real-time chat is the next backend module.\n💬 Voice audio will use a dedicated RTC service.",13);chat.setTextColor(MUTED);chat.setBackground(gd(CARD,20));content.addView(chat);}
    void roomSettings(){final String[] items={"Room enter permission: Everyone","Number of Mic: 10","Mode: Chat","Mic permission: Everyone","Announcement","Room badge","Theme: City","Blocked list","Room Admins: 0/8","Room Backpack","Fruit Party"};new AlertDialog.Builder(this).setTitle("Room Settings").setItems(items,(d,w)->{if(w==4)announcement();else if(w==6)theme();else toast(items[w]);}).show();}
    void announcement(){final EditText e=new EditText(this);e.setText("Welcome everyone! Let's chat and have fun together!");new AlertDialog.Builder(this).setTitle("Announcement").setView(e).setPositiveButton("Save",(d,w)->toast("Announcement saved")).setNegativeButton("Cancel",null).show();}
    void theme(){new AlertDialog.Builder(this).setTitle("Room Theme").setItems(new String[]{"City","Night Sky","Party","Love","VIP Gold"},null).show();}
    void roomActivities(){String[] a={"🎮 Room Mode","🍾 Truth & Dare","🎩 Undercover","🎲 Dominoes","🎨 Draw & Guess","🎲 Ludo","🎤 Talent","🐍 Snakes & Ladders","🟤 Carrom","💣 No Bomb","🍭 Yummy Crush","🎵 Music","🎡 Lucky Wheel","🔢 Calculator","🔊 Sound Effect","💰 Lucky Bag","⚔ PK","🆚 Room PK","💕 Intimacy Bond"};new AlertDialog.Builder(this).setTitle("Room Mode & Play Center").setItems(a,(d,w)->toast(a[w]+" opened")).show();}
    void pk(){new AlertDialog.Builder(this).setTitle("Room PK").setMessage("Challenge another room and start a timed gift battle.\n\nTeam A: 0\nTeam B: 0").setPositiveButton("Find Opponent",null).setNegativeButton("Cancel",null).show();}
    void gifts(){String[] tabs={"Gift","Activity","Intimacy","PK","Playful","VIP","Special"};new AlertDialog.Builder(this).setTitle("🎁 Gifts   •   💎 "+(unlimited?"∞":diamonds)).setItems(tabs,(d,w)->giftCategory(tabs[w])).show();}
    void giftCategory(String cat){if(cat.equals("Special")){if(vip>=5||owner) specialGifts(); else vipGate();return;}String[] g=cat.equals("VIP")?new String[]{"🚗 Red Shadow — 5,777 💎","🐉 Fire Dragon — 6,777 💎","🐯 Blazing Lion — 57,777 💎","🔥 Fire & Thunder — 27,777 💎"}:new String[]{"🌹 Rose — 1 💎","❤️ Heart — 7 💎","🎁 Gift Box — 99 💎","🚗 Car — 777 💎","👑 Crown — 1,777 💎"};new AlertDialog.Builder(this).setTitle(cat+" Gifts").setItems(g,(d,w)->new AlertDialog.Builder(this).setTitle("Send Gift").setMessage(g[w]+"\n\nQuantity: 1").setPositiveButton("Send",(x,y)->toast("Gift action saved for next wallet transaction module")).setNegativeButton("Cancel",null).show());}
    void specialGifts(){new AlertDialog.Builder(this).setTitle("👑 Special Gifts — VIP "+vip).setItems(new String[]{"🌌 Galaxy Crown — 99,999 💎","🐲 Royal Dragon — 199,999 💎","💎 Diamond Storm — 499,999 💎","👑 ECO LEGEND — 999,999 💎"},(d,w)->toast("Special gift selected — transaction module next" )).show();}
    void vipGate(){new AlertDialog.Builder(this).setTitle("👑 Special Gifts Locked").setMessage("Special Gifts are exclusive to VIP 5 & VIP 6 users.\n\nVIP 5: Special Gifts\nVIP 6: All Special Gifts + premium effects").setPositiveButton("View VIP",(d,w)->vip()).setNegativeButton("Close",null).show();}
    void showRank(){base("Leaderboard");content.addView(tv("🏆 Daily Rankings",20));String[] n={"🔥 Lucky Singh","💜 Simran","👑 Aman","🎵 Karan","❤️ Preet"};int i=1;for(String x:n){LinearLayout b=box();b.addView(tv("#"+i+"   "+x+"     💎 "+(10000-i*700),16));content.addView(b,new LinearLayout.LayoutParams(-1,68));i++;}content.addView(tv("\nHost • Sender • Room • Weekly • Monthly",13));}
    void showProfile(){base("My Profile");LinearLayout p=box();TextView av=center(owner?"👑":"🙂",68);p.addView(av);TextView n=center(displayName,22);n.setTypeface(Typeface.DEFAULT,Typeface.BOLD);p.addView(n);TextView id=center("ID: "+publicId,12);id.setTextColor(MUTED);p.addView(id);TextView levelT=center("LV."+level+"   •   XP progress   •   👑 VIP "+vip,14);levelT.setTextColor(MUTED);p.addView(levelT);content.addView(p);addProfileButton("💎 Diamonds     "+(unlimited?"∞":diamonds),()->recharge());addProfileButton("👑 VIP Center     VIP "+vip+" → VIP 6",()->vip());addProfileButton("🎁 My Gifts & Backpack",()->gifts());addProfileButton("🖼 Profile Frame & Avatar",()->toast("Customization module next"));addProfileButton("👥 Followers",()->toast("Followers module next"));addProfileButton("📢 Announcement",()->announcement());if(owner){addProfileButton("🛡 OWNER PANEL",()->toast("Owner controls will be connected server-side"));addProfileButton("🚪 Logout",()->logout());}}
    interface Click{void run();}void addProfileButton(String s,Click c){Button b=btn(s);b.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);b.setOnClickListener(v->c.run());content.addView(b,new LinearLayout.LayoutParams(-1,56));}
    void vip(){String[] v={"VIP 1 — Badge + basic frame","VIP 2 — Entrance effect + daily bonus","VIP 3 — Premium room effects","VIP 4 — Premium frame + name effect","VIP 5 👑 — Special Gifts unlocked","VIP 6 👑 — ALL Special Gifts + exclusive effects"};new AlertDialog.Builder(this).setTitle("👑 VIP Center").setMessage("VIP 1 → VIP 6\n\n"+join(v,"\n\n")+"\n\nSpecial Gifts: VIP 5–6 only").setPositiveButton("View Plans",null).show();}
    String join(String[] a,String sep){StringBuilder s=new StringBuilder();for(int i=0;i<a.length;i++){if(i>0)s.append(sep);s.append(a[i]);}return s.toString();}
    void recharge(){String[] p={"💎 3,000 — ₹100","💎 6,500 — ₹200  +100 Bonus","💎 16,500 — ₹500  +500 Bonus","💎 35,000 — ₹1,000  +2,000 Bonus","💎 80,000 — ₹2,000  +5,000 Bonus","💎 220,000 — ₹5,000  +20,000 Bonus"};new AlertDialog.Builder(this).setTitle("Recharge Diamonds").setItems(p,(d,w)->toast("Payment gateway will be connected later" )).show();}
    void createRoom(){final EditText e=new EditText(this);e.setHint("Room name");new AlertDialog.Builder(this).setTitle("Create Room").setView(e).setMessage("Choose your room settings after creation.").setPositiveButton("Create",(d,w)->room(e.getText().toString().trim().length()==0?"My Party Room":e.getText().toString().trim())).setNegativeButton("Cancel",null).show();}
    void logout(){auth.signOut();currentUser=null;showLogin();}
}
